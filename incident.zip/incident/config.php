<?php
//Google API Key
$GoogleApiKey='AIzaSyAEOYRvV48LM5Tl7ndfjXHiW1vZoaaBvuo';

//Set email to receive report
$sendReportTo=['ncfpellc@gmail.com'];

?>